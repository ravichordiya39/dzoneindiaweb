<!-- start: Main Menu -->
<div id="sidebar-left" class="span2" style="overflow-y: auto;">
  <div class="nav-collapse sidebar-nav">
    <ul class="nav nav-tabs nav-stacked main-menu">
    <li><a href="dashboard.php"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a></li>
    
		<li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Settings </span></a>
    <ul>
         <li><a  href="upload_logo"><i class="icon-file-alt"></i><span class="hidden-tablet">Upload Logo</span></a></li>
         <li><a  href="event_image"><i class="icon-file-alt"></i><span class="hidden-tablet">Banner Image</span></a></li>
         <li><a  href="dashboard-img"><i class="icon-file-alt"></i><span class="hidden-tablet">Dashboard Image</span></a></li>
         <li><a  href="company-menu"><i class="icon-file-alt"></i><span class="hidden-tablet">Company Menu</span></a></li>
        
    </ul>
   </li>

  </div>
</div>
<!-- end: Main Menu -->