
// local 
module.exports = {
    port: 3002,
    appName: 'Betfair APIs Server',
    baseUrl: 'http://172.104.41.239:3002/',
    betFairAPIURL:'http://142.93.36.1/api/v1',
    useQueryString: true,
    databaseConf: {
        host: '172.104.41.239',
        user: 'bat',
        password: 'Welcome@321',
        database: 'bat'
    },
}
