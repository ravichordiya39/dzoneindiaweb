var restify = require('restify');
global.mysql = require('mysql');
global.config = require('./config/config');
global.database = require('./config/database');
global.helper = require('./functions/helper');
global.permission = require('./functions/permission');
global.async = require("async");
global.PHPUnserialize = require('php-unserialize');
global.CronJob = require('cron').CronJob;
global.c = console;
global.axiosForCronJob = require('axios');
var third_party_apis = require('./controllers/third_party_apis');
/**
 * create server
 */
var server = restify.createServer();

/**
 * handle cors middleware 
 */
const corsMiddleware = require('restify-cors-middleware');
const config = require('./config/config');
 
const cors = corsMiddleware({
  preflightMaxAge: 5, //Optional
  origins: ['http://localhost:3000', 'http://localhost', 'localhost:3000', '*'],
  allowHeaders: ['Authorization'],
  exposeHeaders: ['Authorization']
})

server.pre(cors.preflight)
server.use(cors.actual)

server.use(restify.plugins.acceptParser(server.acceptable));
server.use(restify.plugins.authorizationParser());
server.use(restify.plugins.dateParser());
server.use(restify.plugins.queryParser());
server.use(restify.plugins.jsonp());
server.use(restify.plugins.gzipResponse());
server.use(restify.plugins.bodyParser());

// // check body/params 
// server.use(helper.vewRequest);

// add database connection in req object
server.use(database.createDatabaseConnection);

// third party apis for tesing and display data
server.get('/call-third-party-apis/get-sports', third_party_apis.getSports);
server.get('/call-third-party-apis/get-series/:sportsID', third_party_apis.getSeries);
server.get('/call-third-party-apis/get-matches/:sportsID/:seriesID', third_party_apis.getMatches);
server.get('/call-third-party-apis/get-markets/:eventID', third_party_apis.getMarkets);
server.get('/call-third-party-apis/get-markets-selection/:marketID', third_party_apis.getMarketsSelection);
server.get('/call-third-party-apis/get-market-odds/:marketID', third_party_apis.getMarketOdds);
server.get('/call-third-party-apis/get-sessions/:matchID', third_party_apis.getSessions);
server.get('/call-third-party-apis/get-scores/:matchID', third_party_apis.getScores);

// third party apis for updating database
server.get('/call-third-party-apis/update-series', third_party_apis.updateSeries);
server.get('/call-third-party-apis/update-matches', third_party_apis.updateMatches);
server.get('/call-third-party-apis/update-markets', third_party_apis.updateMarkets);
server.get('/call-third-party-apis/update-market-odds', third_party_apis.updateMarketOdds);
server.get('/call-third-party-apis/update-sessions', third_party_apis.updateSessions); // pending
server.get('/call-third-party-apis/update-scores', third_party_apis.updateScores);

// cron will run on every 1 hour for updating Series
var job = new CronJob('* */1 * * *', function() {

  axiosForCronJob.get(config.baseUrl + 'call-third-party-apis/update-series');

}, null, true, 'Asia/Kolkata');
job.start();

// cron will run on every 30 mins for updating Matches
var job = new CronJob('*/30 * * * *', function() {

  axiosForCronJob.get(config.baseUrl + 'call-third-party-apis/update-matches');
  
}, null, true, 'Asia/Kolkata');
job.start();

// cron will run on every 15 mins for updating Markets
var job = new CronJob('*/15 * * * *', function() {

  axiosForCronJob.get(config.baseUrl + 'call-third-party-apis/update-markets');

}, null, true, 'Asia/Kolkata');
job.start();

// cron will run every second for updating Market-Odds
var job = new CronJob('* * * * * *', function() {

  axiosForCronJob.get(config.baseUrl + 'call-third-party-apis/update-market-odds');

}, null, true, 'Asia/Kolkata');
job.start();

// cron will run every second for updating Match-Sessions
var job = new CronJob('* * * * * *', function() {

  axiosForCronJob.get(config.baseUrl + 'call-third-party-apis/update-sessions');

}, null, true, 'Asia/Kolkata');
job.start();

// cron will run every 5 seconds for updating Match Score
var job = new CronJob('*/5 * * * * *', function() {

  axiosForCronJob.get(config.baseUrl + 'call-third-party-apis/update-scores');

}, null, true, 'Asia/Kolkata');
job.start();

/**
 * mound a server on specific port 
 */
server.listen(config.port, function () {
  console.log('%s listening at %s', config.appName, config.baseUrl);
});
