
// local 
module.exports = {
    port: 3001,
    socketPort: 3002,
    appName: 'Bet-In-Vegas Server',
    //baseUrl: 'http://172.104.41.239:3001/',
    baseUrl: 'http://localhost:3001/',
    betFairAPIURL:'http://142.93.36.1/api/v1',
    useQueryString: true,
    databaseConf: {
        // host: 'localhost',
        host: '172.104.41.239',
        user: 'bat',
        password: 'Welcome@321',
        database: 'bat'
    },
}
