
export const appName = "Bat in Vegas";

export const perPage = 10;

// export const baseURL = 'http://172.104.41.239:3001';
// export const socketURL = 'http://172.104.41.239:3002';

export const baseURL = 'http://localhost:3001';
export const socketURL = 'http://localhost:3002';