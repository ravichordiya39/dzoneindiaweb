
export const copyrightYear = new Date().getFullYear();

export const definedMenus = ['/dashboard', '/sub-admins', '/masters', '/players', '/settings', '/pages', '/credits-history', '/sports-listing', '/series-listing'];

