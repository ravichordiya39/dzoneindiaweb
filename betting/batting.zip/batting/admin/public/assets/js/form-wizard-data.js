(function ($) {
    'use strict';
    $(document).ready(function () {
        $('#rootwizard').bootstrapWizard({
            'tabClass': 'nav nav-pills',
            'onNext': function (tab, navigation, index) {

            },

        });
    });
})(window.jQuery);